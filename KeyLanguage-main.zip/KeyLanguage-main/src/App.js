import './App.css';
import MainPage from './CodingView/MainPage'

function App() {
  return (
    <div>
      <MainPage/>
    </div>
  );
}

export default App;

